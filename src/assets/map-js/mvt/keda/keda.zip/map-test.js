function windowLoad(){
	/**
     * 初始化地图实例
     */

	var _initZoom = 10;
	var _center = [108.61271223150084, 34.32346389132387];
	function getQueryString(name, url) {
		if (url && url.indexOf('?') != -1) {
			let str = url.split('?')[1];
			let reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)');
			let r = str.match(reg);
			if (r != null) return unescape(r[2]);
		}
		return null;
	}

	function calMapInitZoom() {
		var url = location.href;
		var z = getQueryString('zoom', url);
		if (z && z.length > 0) {
			_initZoom = parseFloat(z);
		}
	}

	if(location.href.indexOf('lng=') === -1 && (window.frames.length === parent.frames.length)){
		location.href += '?zoom=10&lng=108.93271223150084&lat=34.32346389132387';
	}
	if(window.frames.length === parent.frames.length) {
		_center = [getQueryString('lng', location.href), getQueryString('lat', location.href)];
		calMapInitZoom();
	}
	return {
		configUrl: './config.json',
		center: _center,
		zoom: _initZoom
	};
}
function mapLoad(map) {
	var start_keda = Date.now();
	var flag = false;
	var zoom = 0;
	map.getZoom({
		callback: function (res) {
			zoom = res.data;
		}
	});

	map.addEventOnMap({
		event: 'movestart',
		handler: function(res) {
			flag = true;
			map.getZoom({
				callback: function (res) {
					if (res.data === zoom) {
						start_keda = Date.now();
					}
				}
			});
		}
	});
	map.addEventOnMap({
		event: 'moveend',
		handler: function(res) {
			map.getZoom({
				callback: function (res) {
					zoom = res.data;
					var url = location.href.replace(/zoom=([\d|.]*)/, 'zoom=' + zoom.toFixed(2));
					history.pushState({}, 'url', url);
				}
			});

			map.getCenter({
				callback: function (res) {
					var url = location.href.replace(/lng=([\d|.]*)/, 'lng=' + res.data[0]);
					url = url.replace(/lat=([\d|.]*)/, 'lat=' + res.data[1]);
					history.pushState({}, 'url', url);
				}
			});
		}
	});
};

